<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.tailwindcss.com?plugins=forms,typography,aspect-ratio,line-clamp"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js" type="text/javascript"></script>
    <script src="script.js"></script>
</head>

<body style="background-image:url(blue8.jpg)">
<form id="form1" name="form1" method="get" action="post1.php">
    <section class="text-gray-600 body-font relative" style="margin-top: 3%;">
        <center>
            <div class="container px-5 py-24 mx-auto" id="container" style="margin-top: 10%;width: 700px;padding: 10px;border: 5px solid gray;margin: 0;border-color: rgb(0, 0, 0);background-color: rgba(255, 255, 255, 0.69);box-shadow: 0px 0px 10px rgb(208, 0, 255);">
                <div class="flex flex-col text-center w-full mb-12" style="margin-bottom: 1%;">
                    <h1 class="sm:text-3xl text-2xl font-medium title-font mb-4 text-gray-900">Feedback Form</h1>
                </div>
                <div class="lg:w-1/2 md:w-2/3 mx-auto" id="blank">
                    <div class="flex flex-wrap -m-2">
                        <div class="p-2 w-full">
                            <div class="relative" style="text-align: left;">
                                <label for="name" class="leading-7 text-sm text-gray-600"><b>FullName</b></label>
                                <input type="text" id="TxtName" name="fname" placeholder="Enter FullName here..." maxlength="20"
                                     class="w-full bg-gray-100 bg-opacity-50 rounded border border-gray-300 focus:border-indigo-500 focus:bg-white focus:ring-2 focus:ring-indigo-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out"
                                    style="border-color: rgb(0, 0, 0);">
                                <small id="TxtNameValidation" style="color: red;"></small>
                            </div>
                        </div>
                        <div class="p-2 w-full">
                            <div class="relative" style="text-align: left;">
                                <label for="email" class="leading-7 text-sm text-gray-600"><b>Email</b></label>
                                <input type="text" id="TxtEmailId" name="email" placeholder="Enter EmailId here..." maxlength="40"
                                    class="w-full bg-gray-100 bg-opacity-50 rounded border border-gray-300 focus:border-indigo-500 focus:bg-white focus:ring-2 focus:ring-indigo-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out"
                                    style="border-color: rgb(0, 0, 0);">
                                <small id="TxtEmailIdValidation" style="color: red;"></small>
                            </div>
                        </div>
                        <div class="p-2 w-full" style="text-align: left;">
                            <div class="relative">
                                <label for="email" class="leading-7 text-sm text-gray-600"><b>ContactNo</b></label>
                                <input type="text" id="TxtContactNo" name="contact" placeholder="Enter ContactNo here..." maxlength="10" 
                                    class="w-full bg-gray-100 bg-opacity-50 rounded border border-gray-300 focus:border-indigo-500 focus:bg-white focus:ring-2 focus:ring-indigo-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out"
                                    style="border-color: rgb(0, 0, 0);">
                                <small id="TxtContactNoValidation" style="color: red;"></small>
                            </div>
                        </div>
                        <div class="p-2 w-full">
                            <div class="relative" style="text-align: left;">
                                <label for="subject" class="leading-7 text-sm text-gray-600"><b>Subject</b></label>
                                <input type="text" id="TxtSubject" name="sub" placeholder="Enter Subject here..." maxlength="70"
                                    class="w-full bg-gray-100 bg-opacity-50 rounded border border-gray-300 focus:border-indigo-500 focus:bg-white focus:ring-2 focus:ring-indigo-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out"
                                    style="border-color: rgb(0, 0, 0);">
                                <small id="TxtSubjectValidation" style="color: red;"></small>
                            </div>
                        </div>
                        <div class="p-2 w-full" style="text-align: left;">
                            <div class="relative">
                                <label for="message" class="leading-7 text-sm text-gray-600"><b>Message</b></label>
                                <textarea  id="TxtMsg" placeholder="Enter Message here..." maxlength="300" name="message"
                                    class="w-full bg-gray-100 bg-opacity-50 rounded border border-gray-300 focus:border-indigo-500 focus:bg-white focus:ring-2 focus:ring-indigo-200 h-32 text-base outline-none text-gray-700 py-1 px-3 resize-none leading-6 transition-colors duration-200 ease-in-out"
                                    style="border-color: rgb(0, 0, 0);"></textarea>
                                    <small id="TxtMsgValidation" style="color: red;"></small>
                            </div>
                        </div>
                        <div class="p-2 w-full">
                            <!-- <label for="submit" class="leading-7 text-sm text-gray-600"><b></b></label> -->
                            <input type="Submit" id="BtnSubmit"
                                class="flex mx-auto text-white bg-indigo-500 border-0 py-2 px-8 focus:outline-none hover:bg-indigo-600 rounded text-lg"
                                style="background-color: rgb(0, 128, 255);border-color:black;">
                        </div>
                    </div>
                </div>
            </div>
        </center>
    </section>
</form>

</body>
</html>