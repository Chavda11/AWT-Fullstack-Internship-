<?php
$FullName=$_GET['fname'];
$Email=$_GET['email'];
$ContactNo=$_GET['contact'];
$Subject=$_GET['sub'];
$Message=$_GET['message'];
//GET url limit:250 char
// echo $username."<br/>";
// echo $password;
$username="root";
$server="localhost";
$password="";

$db="assignment3";
$conn=mysqli_connect($server,$username,$password,$db);
// if(!$conn){
//     die("Connection failed".mysqli_connect_error());
//     // die function show an error
// }
$sql="insert into feedback (FullName,Email,ContactNo,Subject,Message) values ('$FullName','$Email','$ContactNo','$Subject','$Message')";
if (mysqli_query($conn,$sql)) {
    echo "inserted successfully";
}
else{
   echo "Error creating table: " . mysqli_error($conn);
}
// $sql = "DELETE FROM person WHERE id=2";

// if (mysqli_query($conn,$sql)) {
//         echo "deleted successfully";
//     }
//     else{
//        echo "Error creating table: " . mysqli_error($conn);
//     }
?>

