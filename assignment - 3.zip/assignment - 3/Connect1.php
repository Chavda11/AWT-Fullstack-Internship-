<?php
$username="root";
$servername="localhost";
$password="";
$db="assignment3";
$conn=mysqli_connect($servername,$username,$password,$db);
if(!$conn){
    die("Connection failed".mysqli_connect_error());
    // die function show an error
}
// $sql="Create database assignment3";
// if(mysqli_query($conn,$sql)){
//     echo "Database created";
// }
// else{
//     echo "error1";
// }
// $sql = "CREATE TABLE feedback(
//     Id INT(12) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
//     FullName VARCHAR(50) NOT NULL,
//     Email VARCHAR(50) NOT NULL,
//     ContactNo INT(10) NOT NULL,
//     Subject VARCHAR(90) NOT NULL,
//     Message VARCHAR(300) NOT NULL
//     )";
// if (mysqli_query($conn,$sql)) {
//     echo "Table feedback created successfully";
//   } else {
//     echo "Error creating table: " . mysqli_error($conn);
//   }
// $sql="insert into feedback (FullName,Email,ContactNo,Subject,Message) values ('karan','karan@gmail.com','1234567890','economy','thanks')";
// if (mysqli_query($conn,$sql)) {
//     echo "inserted successfully";
// }
// else{
//    echo "Error creating table: " . mysqli_error($conn);
// }
// $sql="insert into feedback (FullName,Email,ContactNo,Subject,Message) values ('karan','karan@gmail.com','1234567890','ejhhhhjjjjjjjjjjjjjjjjjjconomy','thanks')";
// if (mysqli_query($conn,$sql)) {
//     echo "inserted successfully";
// }
// else{
//    echo "Error creating table: " . mysqli_error($conn);
// }
// $sql="insert into person1 (username,password,ContactNo,EmailId) values ('karan','1234','9601316858','karanmaheriya4@gmail.com')";
// $sql="insert into person1 (username,password,ContactNo,EmailId) values ('yash','4321','9104999722','karanmaheriya070@gmail.com')";
// if (mysqli_multi_query($conn,$sql)) {
//     echo "inserted successfully";
// }
// else{
//    echo "Error creating table: " . mysqli_error($conn);
// }
// $sql = "DELETE FROM person1 WHERE id=2";
// if (mysqli_multi_query($conn,$sql)) {
//         echo "deleted successfully";
//     }
//     else{
//        echo "Error creating table: " . mysqli_error($conn);
//     }
// $sql = "UPDATE person SET username='Doe' WHERE id=1";

// if (mysqli_query($conn,$sql)) {
//         echo "updated successfully";
//     }
//     else{
//        echo "Error creating table: " . mysqli_error($conn);
//     }
?>
